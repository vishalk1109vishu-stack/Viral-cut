---
name: Bug report
about: Report a problem with ViralCut
---

**Describe the bug**

**To reproduce**
1.
2.
3.

**Expected behavior**

**Actual behavior**

**Environment**
- Deployment: [Docker / Vercel / VPS / local dev]
- Source: [YouTube link / upload]
- Video length:
- Browser + OS:

**Logs**
```
Paste any error messages or relevant log output here.
```
